//(c) Copyright Roland Baranowski. All rights reserved.

using System;
using System.Windows;
using JumpLaunch.ViewModels;
using MS.WindowsAPICodePack.Internal;

namespace JumpLaunch
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public const string AppId = "Roland.Baranowski::JumpLaunch";

        protected override void OnStartup(StartupEventArgs e)
        {
            if (!CoreHelpers.RunningOnWin7)
            {
                MessageBox.Show(Strings.PlatformNotSupported, Strings.OsNotSupported, MessageBoxButton.OK, MessageBoxImage.Stop);
                Shutdown();
            }

            var rs = new ResourceDictionary { Source = new Uri("/Themes/BureauBlack.xaml", UriKind.Relative) };
            Current.Resources.MergedDictionaries.Add(rs);

            var screenHeight = SystemParameters.MaximizedPrimaryScreenHeight;
            var wnd = new MainWindow { DataContext = new MainWindowViewModel()};
            wnd.Left = 0;
            wnd.Top = screenHeight - wnd.Height - 15;
            MainWindow = wnd;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            wnd.Show();
        }

        /// <summary>
        /// Activates the main window.
        /// </summary>
        public void Activate()
        {
            Window mainWindow = MainWindow;
            mainWindow.Activate();
        }
    }
}