//(c) Copyright Roland Baranowski. All rights reserved.
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.WindowsAPICodePack.Shell;
using Microsoft.WindowsAPICodePack.Taskbar;

namespace JumpLaunch
{
    internal sealed class JumpLaunchManager
    {
        #region Fields


        private const string QuickLaunchRelativeLocation = @"Microsoft\Internet Explorer\Quick Launch";

        private readonly TaskbarManager _taskBarManager = TaskbarManager.Instance;
        private JumpList _jumpList;


        private const string FolderIconPathRelativePath = @"imageres.dll";
        private const int FolderIconIndex = 3;

        #endregion

        #region Properties

        #region QuickLaunchFolderPath

        /// <summary>
        /// Gets or sets the quick launch folder path.
        /// </summary>
        /// <value>The quick launch folder path.</value>
        private string QuickLaunchFolderPath { get; set; }

        #endregion

        #region FolderIconPath

        /// <summary>
        /// Gets or sets the folder icon path.
        /// </summary>
        /// <value>The folder icon path.</value>
        private string FolderIconPath { get; set; }

        #endregion

        #endregion

        #region Ctor

        /// <summary>
        /// Initializes a new instance of the <see cref="JumpLaunchManager"/> class.
        /// </summary>
        public JumpLaunchManager()
        {
            _taskBarManager.ApplicationId = App.AppId;

            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            QuickLaunchFolderPath = Path.Combine(appData, QuickLaunchRelativeLocation);

            var windows = Environment.GetFolderPath(Environment.SpecialFolder.System);
            FolderIconPath = Path.Combine(windows, FolderIconPathRelativePath);
        }

        #endregion

        #region Methods

        #region RefreshJumpList

        /// <summary>
        /// Refreshes the jump list.
        /// </summary>
        public void RefreshJumpList()
        {
            if (_jumpList == null)
            {
                _jumpList = JumpList.CreateJumpList();
            }

            _jumpList.ClearAllUserTasks();

            var list = GetQuickLaunchItems();

            foreach (var obj in list)
            {
                var linkObj = obj;
                var name = obj.Name;

                string filePath = linkObj.ParsingName;

                if (obj.IsLink)
                {
                    try
                    {
                        var link = (ShellLink)obj;
                        name = link.Name;
                        linkObj = link.TargetShellObject;

                        var path = MsiShortcutParser.ParseShortcut(link.ParsingName);
                        filePath = !string.IsNullOrEmpty(path) ? path : linkObj.ParsingName;
                    }
                    catch (ExternalException)
                    {
                        //some of the links fail, like ChessTitans
                        continue;
                    }

                }

                var iconRef = new IconReference(filePath, 0);
                if (linkObj is ShellFileSystemFolder)
                {
                    iconRef = new IconReference(FolderIconPathRelativePath, FolderIconIndex);
                }

                var jumpListLink = new JumpListLink(filePath, name)
                                       {
                                           IconReference = iconRef
                                       };
                _jumpList.AddUserTasks(jumpListLink);
            }

            _jumpList.Refresh();
        }

        #endregion

        #region GetQuickLaunchItems

        /// <summary>
        /// Gets the quick launch items.
        /// </summary>
        /// <returns></returns>
        public List<ShellObject> GetQuickLaunchItems()
        {
            var dir = new DirectoryInfo(QuickLaunchFolderPath);
            dir.Create();
            var list = new List<FileInfo>();

            var files = dir.GetFiles("*.lnk");
            if (files.Length > 0)
            {
                list.AddRange(files);
            }
            files = dir.GetFiles("*.exe");
            if (files.Length > 0)
            {
                list.AddRange(files);
            }

            if (list.Count > 0)
            {
                list.Sort((x, y) => x.Name.CompareTo(y.Name));
            }

            return list.ConvertAll(x => JumpListItem.FromParsingName(x.FullName));
        }

        #endregion

        #region AddTasks

        public void AddTasks(ShellObjectCollection collection)
        {
            foreach (ShellObject shellObj in collection)
            {
                if (!shellObj.IsLink)
                {
                    continue;
                }

                var name = Path.GetFileName(shellObj.ParsingName);
                File.Copy(shellObj.ParsingName, Path.Combine(QuickLaunchFolderPath, name), true);
            }

        }

        #endregion

        #endregion


    }
}