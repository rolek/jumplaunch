﻿//(c) Copyright Roland Baranowski. All rights reserved.

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using JumpLaunch.ViewModels;
using Microsoft.WindowsAPICodePack.Shell;

namespace JumpLaunch
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Fields

        private Point _dragStart;
        private DataObject _dataObject = null;
        private bool _inDragDrop = false;

        #endregion


        #region Properties

        #region ViewModel

        /// <summary>
        /// Gets or sets the view model.
        /// </summary>
        /// <value>The view model.</value>
        private MainWindowViewModel ViewModel
        {
            get { return DataContext as MainWindowViewModel; }
        }

        #endregion

        #endregion

        #region Ctor

        public MainWindow()
        {
            InitializeComponent();

            DataContext = this;
        }

        #endregion

        #region Title_MouseDown

        private void Title_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        #endregion

        #region Title_MouseLeave

        private void Title_MouseLeave(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Arrow;
        }

        #endregion

        #region Title_MouseEnter

        private void Title_MouseEnter(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.SizeAll;
        }

        #endregion

        #region LstQuickLaunchList_SelectionChanged

        private void LstQuickLaunchList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ViewModel.DeleteCommand.RaiseCanExecuteChanged();
        }

        #endregion

        #region LstQuickLaunchList_Drop

        private void LstQuickLaunchList_Drop(object sender, DragEventArgs e)
        {
            if (!_inDragDrop)
            {
                string[] formats = e.Data.GetFormats();
                foreach (string format in formats)
                {
                    // Shell items are passed using the "Shell IDList Array" format. 
                    if (format == "Shell IDList Array")
                    {
                        // Retrieve the ShellObjects from the data object
                        var elements = ShellObjectCollection.FromDataObject(e.Data);
                        ViewModel.AddTasks(elements);
                        e.Handled = true;
                        return;
                    }
                }
            }

            e.Handled = false;
        }

        #endregion

    }
}