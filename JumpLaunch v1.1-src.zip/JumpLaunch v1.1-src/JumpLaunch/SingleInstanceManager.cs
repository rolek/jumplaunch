//(c) Copyright Roland Baranowski. All rights reserved.
using System;
using Microsoft.VisualBasic.ApplicationServices;

namespace JumpLaunch
{
    /// <summary>
    /// This is an application entry point
    /// </summary>
    internal class EntryPoint
    {
        [STAThread]
        public static void Main(string[] args)
        {
            var manager = new SingleInstanceManager();
            manager.Run(args);

        }
    }

    /// <summary>
    ///     Using VB bits to detect single instances and process accordingly:
    ///   * OnStartup is fired when the first instance loads
    ///   * OnStartupNextInstance is fired when the application is re-run again
    ///     NOTE: it is redirected to this instance thanks to IsSingleInstance
    /// </summary>
    internal class SingleInstanceManager : WindowsFormsApplicationBase
    {
        private App _app;

        /// <summary>
        /// Initializes a new instance of the <see cref="SingleInstanceManager"/> class.
        /// </summary>
        internal SingleInstanceManager()
        {
            IsSingleInstance = true;
        }

        protected override bool OnStartup(StartupEventArgs e)
        {
            _app = new App();
            _app.Run();
            return false;
        }

        protected override void OnStartupNextInstance(StartupNextInstanceEventArgs eventArgs)
        {
            base.OnStartupNextInstance(eventArgs);
            _app.Activate();
        }
    }
}