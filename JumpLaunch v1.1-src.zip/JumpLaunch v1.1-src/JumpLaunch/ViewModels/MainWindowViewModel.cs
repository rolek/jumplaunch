//(c) Copyright Roland Baranowski. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using JumpLaunch.Commands;
using Microsoft.WindowsAPICodePack.Shell;

namespace JumpLaunch.ViewModels
{
    /// <summary>
    /// Represents the view model for main window
    /// </summary>
    internal class MainWindowViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// The _manager.
        /// </summary>
        private readonly JumpLaunchManager _manager = new JumpLaunchManager();

        #endregion

        #region Commands

        #region RefreshListCommand

        /// <summary>
        /// The _refresh list command.
        /// </summary>
        private DelegateCommand<object> _refreshListCommand;

        /// <summary>
        /// Gets or sets the refresh list command.
        /// </summary>
        /// <value>The refresh list command.</value>
        public DelegateCommand<object> RefreshListCommand
        {
            get
            {
                if (_refreshListCommand == null)
                {
                    _refreshListCommand = new DelegateCommand<object>(RefreshListCommand_Executed);
                }

                return _refreshListCommand;
            }

            set { _refreshListCommand = value; }
        }

        #endregion

        #region DeleteCommand

        /// <summary>
        /// The _delete command.
        /// </summary>
        private DelegateCommand<ShellObject> _deleteCommand;

        /// <summary>
        /// Gets or sets the delete command.
        /// </summary>
        /// <value>The delete command.</value>
        public DelegateCommand<ShellObject> DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new DelegateCommand<ShellObject>(DeleteCommand_Executed, DeleteCommand_CanExecute);
                }

                return _deleteCommand;
            }

            set { _deleteCommand = value; }
        }

        #endregion

        #endregion

        #region Properties

        #region Title

        /// <summary>
        /// Gets or sets the window title.
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; set; }

        #endregion

        #region QuickLaunchList

        /// <summary>
        /// Gets or sets the quick launch list.
        /// </summary>
        /// <value>The quick launch list.</value>
        private ObservableCollection<ShellObject> _quickLaunchList;

        /// <summary>
        /// Gets or sets QuickLaunchList.
        /// </summary>
        public ObservableCollection<ShellObject> QuickLaunchList
        {
            get { return _quickLaunchList; }
            set
            {
                _quickLaunchList = value;
                OnPropertyChanged("QuickLaunchList");
            }
        }

        #endregion

        #endregion

        #region Ctor

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindowViewModel"/> class.
        /// </summary>
        public MainWindowViewModel()
        {
            Title = App.AppId;
            PrepareItemsToBind();
        }

        #endregion

        #region CommandHandlers

        #region RefreshListCommand_Executed

        /// <summary>
        /// The refresh list command_ executed.
        /// </summary>
        /// <param name="obj">
        /// The obj.
        /// </param>
        private void RefreshListCommand_Executed(object obj)
        {
            _manager.RefreshJumpList();
        }

        #endregion

        #region CloseCommand_Executed

        /// <summary>
        /// The close command_ executed.
        /// </summary>
        /// <param name="argument">
        /// The argument.
        /// </param>
        protected override void CloseCommand_Executed(object argument)
        {
            Application.Current.Shutdown();
        }

        #endregion

        #region DeleteCommand_CanExecute

        /// <summary>
        /// CanExecute handler for Delete Command
        /// </summary>
        /// <param name="arg">
        /// The arg.
        /// </param>
        /// <returns>
        /// The delete command_ can execute.
        /// </returns>
        private bool DeleteCommand_CanExecute(ShellObject arg)
        {
            return arg != null;
        }

        #endregion

        #region DeleteCommand_Executed

        /// <summary>
        /// Handles delete command CanExecuted event.
        /// </summary>
        /// <param name="param">
        /// The command parameter.
        /// </param>
        private void DeleteCommand_Executed(ShellObject param)
        {
            try
            {
                if (File.Exists(param.ParsingName))
                {
                    File.Delete(param.ParsingName);
                }

                QuickLaunchList.Remove(param);
                RefreshListCommand.Execute(null);
            }
            catch
            {
                MessageBox.Show(string.Format(Strings.ErrorRemovingFileFormat, param.Name));
            }
        }

        #endregion

        #endregion

        #region Methods

        #region PrepareItemsToBind

        /// <summary>
        /// The prepare items to bind.
        /// </summary>
        private void PrepareItemsToBind()
        {
            List<ShellObject> list = _manager.GetQuickLaunchItems();
            QuickLaunchList = list.Count > 0 ? new ObservableCollection<ShellObject>(list) : new ObservableCollection<ShellObject>();
        }

        #endregion

        #region AddTasks

        /// <summary>
        /// Adds the tasks.
        /// </summary>
        /// <param name="collection">
        /// The collection.
        /// </param>
        public void AddTasks(ShellObjectCollection collection)
        {
            try
            {
                _manager.AddTasks(collection);
            }
            catch (Exception)
            {
                MessageBox.Show(Strings.ErrorCopyingFiles);
            }

            PrepareItemsToBind();
            RefreshListCommand.Execute(null);
        }

        #endregion

        #endregion
    }
}