**Project Description**
Did you ever wondered where is the quick launch bar in Windows 7?
JumpLaunch is a missing link between taskbar and user. It is a simple program that can display quick launch shortcuts in a jump list. Just "pin" it to the taskbar and it is ready to use.

**REQUIRES - Microsoft .NET Framework 3.5 Service Pack 1**

**Compatibility: Windows 7 / Windows 8.1 (not tested on pure 8.0)**

**Screenshots**

Download here:	[release:36218](release_36218)

![Main window](Home_mainWindow.png)
Main window

The screenshots below are not updated.
**_Application does not require elevation_**. The screenshots will be updated soon (the shield should be gone).

![Icon](Home_taskbar-icon.png)
Taskbar icon

![Jumplist](Home_jumplist.png)
Jumplist in action

**WPF Clarification**
Some people / reviews are asking, why WPF for such small utility. The answer is that this was a module of a bigger software I wrote. I was never bothered to rewrite it. 



